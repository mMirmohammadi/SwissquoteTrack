# Swissquote Wallet

**FINAL V4 acceptance:** `bash-2077`, exit 0: `GATE PASS: passed=609, skipped=0, duration=434.2s`; typechecks/builds passed. This includes the seven added MOCK bank-return shortcut regressions (567 Node/browser + 42 contracts). It supersedes the earlier 602-test baseline below. G1 public-browser recovery separately passed across retained sessions, not one uninterrupted take. No production audit, hardware proof or publication is implied.

**Clients keep their payment key; Swissquote helps with card-required recovery and network fees.** A one-owner Safe pays with the client's signature. Two separate recovery modules require Recovery Card + partner or Recovery Card + Swissquote; the helpers together without the card do not meet either intended rule. An unlocked key can spend immediately, and the app publisher remains trusted.

## CURRENT V4 acceptance

The isolated, **uncommitted V4 candidate** passed `bash-1996`, exit 0: **602 passed, zero skipped, 417.0 seconds**, with typecheck/build passing. That is 560 Node/browser + 42 contract tests (historical frozen 591 + 8 launcher + 3 UI); 34 browser tests include local recovery with a real 180-second wait. [Durable V4 acceptance](<Docs/plans/v4/acceptance.md>). Frozen v3 remains clean at `cb7297a`. This is not a production security audit or acceptance of further proposed UI changes. **G1 public-browser recovery PASSED:** the same wallet completed creation, payment, card+partner recovery and replacement-owner payment across encrypted retained browser sessions after timeouts—not one uninterrupted take. Finalization/new payment used normal unlock on one page; virtual WebAuthn and MOCK identity remain limits. See [completed evidence](<Docs/submission/claims.md#g1-public-browser-recovery--completed-across-retained-sessions>).

## Public Sepolia proof — separate runs, test funds only

| Evidence | What ran | Limit |
| --- | --- | --- |
| [Zero-ETH 1-USDC payment](https://sepolia.etherscan.io/tx/0xe3188195628404c7da0883744aa6562c45e6597fe32c636e72fb3890801dc77e) | Browser + services; Swissquote RELAYER paid gas | Virtual WebAuthn; MOCK identity/bank |
| [1-USDC test supply](https://sepolia.etherscan.io/tx/0xa44904bd58728a3cdeef571a6c0aa7c23aaa5af7cad7bc618fafd2ea1b3694af) | Browser + services; second wallet, allowance reset zero | Third-party Compound III test deployment; no withdrawal/swap |
| [Recovery after real 180-second wait](https://sepolia.etherscan.io/tx/0x1231c281bbb949ea3c64917618b4f626cc70a77a0621b7a2d763ae95de3c743e) | **SCRIPTED** Sepolia; local browser recovery separately passed | Historical SCRIPTED run; completed G1 public-browser evidence is recorded separately |
| [Cancel both recoveries](https://sepolia.etherscan.io/tx/0x4bbdd6bd0b25a2981e7f7f6fa4dc2b9c9fe75b6b5252e543f930fe1838980681) | **SCRIPTED** owner cancellation | Not public service-alert proof |
| [RPC-only kit exit, 3 USDC](https://sepolia.etherscan.io/tx/0xbc661bfd7f78d65385f7f7bcb4bcc6231205312e6a3e510401b34b8268e9110c) | **SCRIPTED**, no helper-service calls; FUNDER gas | Desk exports/checks the key, did not broadcast sweep; no shutdown drill |

The [historical frozen-v3 gate](<Docs/plans/v3/compound-acceptance.md>) passed **591 tests, zero skips**, typechecks/builds. Its recorded results remain unchanged; the current isolated candidate's acceptance is V4 above. [Exact evidence ledger](<Docs/submission/claims.md>).

## Architecture and MOCKs

[Interactive real-versus-MOCK diagram](<Docs/submission/architecture.html>) and [architecture explanation](<Docs/submission/architecture.md>). Live sanctions-oracle/USDC blacklist reads and linked public transactions are real. Bank account/funding provenance, KYC, face/video checks, mailbox, demo sanctions entries and SQLite helper vaults are MOCK. No production bank/regulatory/security approval is claimed.

## Run locally — instructions inspected, not clean-clone rehearsed here

Use Node 26 and pnpm 12.6.0 from the [manifest](<swissquote-wallet/package.json>). From the repository root:

    cd swissquote-wallet
    pnpm install
    npm --prefix contracts install
    pnpm demo:local

The launcher starts **its own fresh local chain**, compiles/initializes fixtures and launches wallet/tool/services. Do not start a separate chain or run devnet first. It refuses occupied owned ports and local dotenv files rather than attaching to an existing demo. Defaults: wallet localhost:5273, Recovery Desk localhost:5274, services 4101/4102, RPC 8645. No real keys; no public chain commands are required. [Run guide](<swissquote-wallet/README.md>); [launcher source](<swissquote-wallet/scripts/v3-local.mjs>).

## Judge documents and human inputs

[Submission](<Docs/submission/SUBMISSION.md>) · [Judge guide](<Docs/submission/README.md>) · [Threat model](<Docs/submission/threat-model.md>) · [Legal argument and risks](<Docs/submission/custody-travel-rule.md>) · [Hypothetical business case](<Docs/submission/business-case.md>) · [AI disclosure](<Docs/submission/ai-tools.md>) · [Docs handoff](<Docs/submission/IMPLEMENTATION.md>).

Video, screenshots, public artifact URLs, repository visibility and every human's AI usage remain pending. Documentation is prepared for review on v4-docs, not applied to v3 or published/submitted. Working plans are not verified product behavior. No screenshot is substituted for a live execution receipt.
