# Evidence and verification boundaries

Sponsored payment (wallet and owner needed no ETH):
https://sepolia.etherscan.io/tx/0xe3188195628404c7da0883744aa6562c45e6597fe32c636e72fb3890801dc77e

Recovery finalized after a real wait:
https://sepolia.etherscan.io/tx/0x2de7323c1e8de99119cd2ba651794e90e252c3c0729961bd8d7132485c62fa5e

Replacement owner paid from the same wallet:
https://sepolia.etherscan.io/tx/0xaf43a7e72b8f8f951fef5d68b73700525416e1581f25c44e81edc2de3053976a

Separate built-in DeFi test supply (third-party test deployment, not an official Compound market):
https://sepolia.etherscan.io/tx/0xa44904bd58728a3cdeef571a6c0aa7c23aaa5af7cad7bc618fafd2ea1b3694af


## Retained records
The adjacent JSON records are retained earlier execution evidence, not fresh runs of the packaged snapshot. Browser recovery completed across resumed sessions after timeouts, not a single uninterrupted take. The scripted full story is separate from browser evidence. A real read-only old-key rejection is not a mined failed transaction. The active Demo lab explains attacks rather than broadcasting them.

No new wallet transaction was sent while building this archive. The latest whole-suite pass predates subsequent UI edits; a later full run failed during recovery waiting. Scoped tests are not a current full-suite pass.
