# Recovery, theft and service disappearance
On a replacement device the client prepares a new encrypted owner key, reviews the replacement address, obtains a card approval through the Desk and a matching helper approval, and submits recovery. After the waiting period the owner can be replaced without changing the wallet address. The old owner's signature is then invalid. Pending requests on both modules must be considered; the UI detects a conflicting other-module request but requires manual handling.

If Swissquote is unavailable, the card-plus-partner path does not require Swissquote to be a guardian. If helper services are unavailable, the Emergency Kit provides the original owner material and instructions for using a funded independent submitter. The retained exit demonstration used an RPC-only script; external MetaMask-to-Safe spending and an actual all-services-down rehearsal have not been demonstrated. Working chain access and transaction fees are still required.

For a stolen unlocked owner key, recovery is not a refund or reversal mechanism. Funds already stolen cannot be restored by changing the owner. The included threat-model discussion distinguishes losing access from leaking a spending key.

