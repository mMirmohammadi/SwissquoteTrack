# AI tools
AI assistants accessed through DeepSeek Harness helped with implementation, research synthesis, parallel design/security critique, tests, documentation and presentation. Confirmed tooling included gpt-6.1-sol and Archify. AI is not part of the runtime signing or recovery trust model. Individual contributors' unverified model usage is not invented.

