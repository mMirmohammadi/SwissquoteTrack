# Custody and threat model
The normal payment authority is the single Safe owner: the client's key. Login authenticates the client to the service; it does not itself sign a payment or decrypt the device key.

Recovery uses two independent module instances. Module A requires the Recovery Card plus the partner and has a three-minute demonstration delay. Module B requires the Recovery Card plus Swissquote and has a three-day delay. Each module requires both of its configured guardians. Swissquote alone, the partner alone, or both helpers without the card cannot satisfy either intended threshold. The current owner can cancel pending recovery.

The Recovery Card is not the ordinary spending key. The Emergency Kit is different: its encrypted file plus separate kit code can recover the owner seed. Those materials must be stored separately. An old kit no longer controls the wallet after the owner has been replaced.

This design does not eliminate all threats. A stolen unlocked owner key can spend or alter the wallet. A malicious or compromised publisher can serve JavaScript that steals secrets. A stolen card plus a fooled matching helper can initiate recovery. Cancellation depends on detection, availability and transaction ordering. Identity checks and helper-key vault protections remain mocked. This is not an audited production system.


# Custody, Travel Rule and legal position
Our technical design supports client control of ordinary spending, but that does not settle Swiss legal classification. Conditional recovery authority, application publication, sponsored execution and the full service need counsel and bank review. We do not claim a FINMA ruling, exemption or production approval.

A proposed bank-to-wallet boundary associates the authenticated client with a wallet through a purpose-limited ownership signature. Signature validity, KYC, beneficial ownership and transaction approval are different checks. A wallet ownership signature alone does not prove a complete Travel Rule process.

For sponsored wallet payments the client signs the exact destination and amount while the relayer submits and pays the fee. That is a technical distinction, not a legal conclusion that Swissquote cannot be an obligated intermediary. Production would require approved AML, sanctions coverage, records, privacy arrangements, liability allocation and incident response. The current screening is a bounded prototype control, not comprehensive Swiss compliance.

