# Swissquote Wallet — project description

People should not have to choose between controlling their money and having a way back after losing a device. Our prototype combines a bank-familiar wallet experience with a user-controlled payment key.

The wallet is a one-owner Safe on Ethereum Sepolia. The owner key is generated locally and stored encrypted in the browser. Swissquote’s service sponsors approved transactions, so the client can send test USDC without holding ETH. Logging in authenticates the account; it does not give Swissquote the payment key.

Recovery requires a separate 12-word Recovery Card plus one helper. Two Candide recovery modules provide distinct paths: card + partner after a three-minute demo wait, or card + Swissquote after three days. Neither helper alone, nor both helpers together without the card, can satisfy either recovery threshold. The existing owner can cancel a pending recovery. An encrypted Emergency Kit and separate browser tool provide a further exit path without helper-service calls.

We demonstrated public-Sepolia wallet creation, owner-signed sponsored payment, card-plus-partner recovery after the real waiting period, and a replacement-owner payment at the same wallet address. The browser recovery evidence spans resumed sessions, not one uninterrupted take. Separate script evidence records both-helper refusal, recovery cancellation and an RPC-only Emergency Kit sweep. A separate browser run supplied test USDC to a third-party Compound III test deployment through the built-in allow-listed DeFi flow.

The prototype also includes payment previews, recipient checks, public-chain screening reads, account-to-wallet ownership proof, recovery alerts while the wallet is open, and a separate Recovery Desk. The product aims to retain the bank relationship through optional recovery assistance and fee sponsorship while allowing clients to control and leave with their assets. Subscription pricing and commercial demand remain hypotheses, not validated revenue.

Real: Safe contracts, signatures, Sepolia transactions, sponsored fees and the recorded recovery wait. Mocked: bank balances/origin, KYC, face/video identity checks and helper-key vaults. This is a hackathon prototype, not an audited production wallet or a claim of regulatory approval. The custody and Travel Rule analysis distinguishes client signatures, bank withdrawals and sponsored third-party transactions; production classification and compliance require legal and bank review.


## Technology

TypeScript, React/Vite, Node.js, SQLite, Safe v1.4.1, Candide Social Recovery Module v0.0.1, viem, WebAuthn, WebCrypto, Sepolia and USDC.

## AI disclosure

AI coding/research assistants accessed through DeepSeek Harness supported implementation, design/security critiques, testing, documentation and presentation. Confirmed tooling included gpt-6.1-sol and Archify. AI is not in the wallet signing or recovery trust model. Individual human tools and authorship are not inferred.
