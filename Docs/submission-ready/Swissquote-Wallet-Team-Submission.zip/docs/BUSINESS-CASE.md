# Business case
The target customer wants self-custody without losing the familiar bank relationship. Swissquote could offer optional recovery assistance and sponsored payments while maintaining an easy path back to its trading services. The Emergency Kit deliberately permits exit rather than locking the client in.

Revenue hypotheses include an opt-in assistance subscription and retained trading engagement. They are hypotheses, not validated demand or forecasts. For transparent unit arithmetic only, an assumed CHF 4.90 monthly subscription is CHF 58.80 gross per paying account per year; 2,000 assumed subscriptions would be CHF 117,600 gross annually before costs. No actual subscribers, tariff approval, retention lift or profit is claimed.

A next-stage pilot should measure successful setup and recovery completion, comprehension of card versus kit, support burden, fraud/refusal outcomes, sponsorship cost and willingness to pay. Production rollout depends on independent security and legal review.

