# Prototype limits

- Self-custody is a technical design claim, not FINMA approval. Swissquote has no ordinary owner key; the client card plus a helper can authorize delayed owner replacement. The full service, conditional authority and publisher risks require legal review.
- Bank balances/origin, KYC, face/video checks and helper-key vaults are MOCK. Public Sepolia transactions and sponsored fees are real testnet execution, not real-money banking.
- Partner recovery waits three minutes; Swissquote fallback waits three days. Full live completion of the latter is not established.
- An unlocked owner key or malicious served app can compromise funds. The card cannot reverse theft. Cancellation is not guaranteed to win a race.
- Passkeys authenticate login and high-value sponsorship; they are not the on-chain owner key and do not decrypt the device seed.
- WalletConnect is not integrated. Built-in allow-listed DeFi is narrower; the recorded Compound supply used a third-party test deployment, not an official market.
- Closed-device server/email recovery notifications and receive QR are not implemented. External MetaMask-to-Safe Emergency Kit spending is not demonstrated; an RPC-only scripted exit is recorded.
- Screening controls sponsorship, not what an owner can self-fund. It is not regulatory clearance or comprehensive production AML.
- The latest full-suite pass is historical; later UI changes were not followed by a successful complete gate. No fresh clean-machine install was performed for this archive.
- Commercial demand and subscription pricing are hypotheses, not measured adoption or guaranteed revenue. Solana discussed in the pitch is proposed, not implemented.
