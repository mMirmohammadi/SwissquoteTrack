// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @notice MOCK test token, local Hardhat only. Never deploy on a public chain.
contract DemoUSDC is ERC20 {
    constructor() ERC20("MOCK Sepolia USDC", "USDC") {}
    function decimals() public pure override returns (uint8) { return 6; }
    function mint(address to, uint256 amount) external { _mint(to, amount); }
}
