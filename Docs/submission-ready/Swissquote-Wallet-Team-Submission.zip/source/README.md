# Run the source snapshot

Current uncommitted V4 source is in swissquote-wallet/. This archive does not claim a published Git revision or a clean-machine verification.

Prerequisites: Node 26 and pnpm 12.6.0 (the packageManager pin). Internet is needed to install dependencies. Use a development machine, not an account holding real assets.

    cd swissquote-wallet
    pnpm install
    npm --prefix contracts install
    pnpm demo:local

The launcher starts an isolated local chain and both applications/services. Do not start a separate chain first. Required free local ports: 5273, 5274, 4101, 4102 and 8645. Open http://localhost:5273 for the wallet and http://localhost:5274 for the separate Recovery Desk. Stop with Ctrl-C. Local mode does not require private Sepolia keys. The launcher refuses conflicting ports/local dotenv files. Only use test funds and test identities.

Additional checks, from swissquote-wallet/:

    pnpm typecheck
    pnpm build
    pnpm test
    pnpm test:contracts

These commands are instructions, not a claim they were rerun on a clean machine for this ZIP. Contract fixtures use public deterministic development keys; never fund those keys on a public network. Package downloads and native dependencies may require platform-specific build tools.

Public Sepolia mode needs separately supplied funded credentials; none are included. Do not use public mode merely to inspect this submission. Never send seeds, card words, kit codes or private keys to the team or an AI assistant.

Historic source README files may describe older milestones. This file and docs/LIMITATIONS.md are the packaging-time authority for verification status.
