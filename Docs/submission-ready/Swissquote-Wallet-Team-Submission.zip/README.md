# Swissquote Wallet — complete hackathon submission

Track: Swissquote — Build the Swissquote Wallet.
Team members: Mehrshad Mirmohammadi and Erfan Mousavian.

Open START-HERE.html after extracting. For the complete written entry, read SUBMISSION.pdf or SUBMISSION.md. These are the submission itself, not an internal preparation checklist.

## Included
- Full written submission: problem, product, custody and threat model, real/mock architecture, wallet creation, authentication, recovery, service disappearance, legal/Travel Rule position, business case, bonuses, AI disclosure and evidence boundaries.
- Selected technical pitch and speaker notes in offline HTML and PDF.
- Architecture image.
- Public transaction links and retained JSON records.
- Current V4 source code with local-run instructions.
- Checksummed file manifest.

All prepared materials are included. No external repository access is necessary to inspect the source. The presentation and written submission open offline; public explorers and dependency installation require internet.

## Evaluation
Start with SUBMISSION.pdf, then pitch/pitch.pdf. Use docs/EVIDENCE.md for transaction receipts and source/README.md to run an isolated local demo. The source is the uncommitted V4 snapshot, not a claim about the current public repository branch.

## Honest boundaries
This is a hackathon prototype, not a production audit or regulatory approval. No runtime credentials, real user databases, installed dependencies or recorded live-demo video are included. The team is Mehrshad Mirmohammadi and Erfan Mousavian. Contact fields belong to the submitting DoraHacks account. The latest whole-suite pass is historical; current-source limitations are documented in SUBMISSION.pdf and docs/LIMITATIONS.md.
